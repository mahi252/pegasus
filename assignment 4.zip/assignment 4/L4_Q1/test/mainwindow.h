#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
using namespace std;
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
    struct Trie {
        bool isEndOfWord;
        map<char,struct Trie*> map;
        string meaning;
    };

public:
    Trie* root = NULL;
    void read();
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    //global cvarand functions
    Trie* getNewTrieNode()
    {
        Trie* node = new Trie;
        node->isEndOfWord = false;
        return node;
    }
    void insert(Trie*& root, const string& str,
                const string& meaning)
    {

        // If root is null
        if (root == NULL)
            root = getNewTrieNode();

        Trie *temp = root;
        for (int i = 0; i < str.length(); i++) {
            char x = str[i];

            // Make a new node if there is no path
            if (temp->map.find(x) == temp->map.end())
                temp->map[x] = getNewTrieNode();

            temp = temp->map[x];
        }

        // Mark end of word and store the meaning
        temp->isEndOfWord = true;
        temp->meaning = meaning;
    }

    /**
    *gets meaning of required word
    */
    string getMeaning( const string& word)
    {

        // If root is null i.e. the dictionary is empty
        if (root == NULL)
            return "Invaid word";

        Trie* temp = root;

        // Search a word in the Trie
        for (int i = 0; i < word.length(); i++) {
            temp = temp->map[word[i]];
            if (temp == NULL)
                return "Invalid word";
        }
        if (temp->isEndOfWord)
            return temp->meaning;
        return "Invalid word";
    }

private slots:
    void on_pushButton_clicked();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
