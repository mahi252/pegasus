#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QFile>
#include<QTextStream>
#include<bits/stdc++.h>
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    read();
}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::read(){
   /* vector<string> row;
        string word;
        QFile file(":/L4_P1_input.csv");
        if (!file.open(QIODevice::ReadOnly))
        {
            ui->textEdit->setText("File not found");
            return;
        }
        QTextStream in(&file);

        while (!in.atEnd()) {
            cout<<"reading doc"<<endl;
            QString line = in.readLine();
            string line1 = line.toUtf8().constData();
            cout<<line1<<endl;
            stringstream so(line1);
            while (getline(so, word, ',')) {

                       // add all the column data
                       // of a row to a vector
                       row.push_back(word);
                   }
            cout<<row[0]<<endl;
            cout<<row[1]<<endl;
            insert(root,row[0],row[1]);}
QCoreApplication::applicationDirPath() +*/
    QFile file( ":/L4_P1_input.csv");
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
            return;
        char ch;
        char keys[100][100];

            char keys1[100][100];
            int countl=0,i=0,j=0,quotes=0,k=0,l=0,y=0,count=0;
        QTextStream in(&file);
        while (!in.atEnd()) {
            //QString line = in.readLine();
            QChar oneChar = ' ';
                in >> oneChar;
                ch=oneChar.toLatin1();
            y=0;
               if(ch=='\n'){ y=1;  i++; k++; countl--; count++; }
               if(ch=='\"'){ y=1; quotes++; if(quotes%2==0){  l=0; j=0; } }
               if(quotes%2==0) {if(ch==','){ y=1; countl++; j=0; l=0;  } }
               if(y==0){
               if(countl%2==0) { keys[i][j]=ch; j++; }
               else{ keys1[k][l]=ch; l++; }
               }
        }
        for (i = 0; i < count; i++)
               {
               insert(root, keys[i],keys1[i]);
            }


}
void MainWindow::on_pushButton_clicked()
{
    QString ip=ui->lineEdit->text();
    string linestring = ip.toUtf8().constData();
    string str;
       // cin>>str;
        str=getMeaning( linestring);
    QString qs = QString::fromLocal8Bit(str.c_str());
    //
    ui->textEdit->setText(qs);}
