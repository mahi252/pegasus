// C++ implementation to find the length
// of longest subarray having sum k
#include <bits/stdc++.h>
using namespace std;

// function to find the length of longest
// subarray having sum k
int index1;
int lenOfLongSubarr(int arr[],
                    int N,
                    int n)
{

    // unordered_map 'um' implemented
    // as hash table
    map<int, int> um;
    int sum = 0, maxLen = 0,z ;

    // traverse the given array
    for (int i = 0; i < N; i++) {

        // accumulate sum
        sum += arr[i];

        // when subarray starts from index '0'
        if (sum == n) {
            maxLen = i + 1;
            z = 1;
            }

        // make an entry for 'sum' if it is
        // not present in 'um'
        if (um.find(sum) == um.end())
            um[sum] = i;

        // check if 'sum-k' is present in 'um'
        // or not
        if (um.find(sum - n) != um.end()) {

            // update maxLength
            if (maxLen < (i - um[sum - n])){
                maxLen = i - um[sum - n];
                z = 2;
        }
         }

    }
    if(z==1){
        index1 = 0;
    }
    if(z==2){
        index1 =um[sum - n] + 1;
    }

    // required maximum length
    return maxLen;
}

// Driver Code
int main()
{
   int N,n,p;
    cout<<"Enter the length of the array"<<endl;
    cin >> N;
   int arr[N] ;
for (int i = 0; i < N; ++i){
    cin >> arr[i] ;
    }
    cin >> n;
    p = lenOfLongSubarr(arr, N, n);
    cout << "Length of longest subarray  = "<< p<<endl;
         cout<< "index from " << index1<<" to "<<index1 +p -1<<endl;
    return 0;
}
