
/**
* @file MAT.C
* @brief this file is to represent any region (in image array representation), into
*its quadtree form.
*
* @author G.Mahidhar
*
* @date 18/08/2019
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int akl=1;
void split();
int quad();

/**
* This method is used to represent the given array(image) into quadtree form
* @author G.Mahidhar
* @param 2D array
* @date 18/08/2019
*/
 int main(){
int counter = 0,i ;
  FILE *fp = fopen("D://array.txt", "r");
  /*char temp[10000];
 int counter = 0,i ;
 while( fgets (temp, 10000, fp)!=EOF ) {
        if(temp==48 || temp==49)
     counter ++;
 }
 fclose(fp);*/
 int rl;
 while(EOF!=fscanf(fp,"%d ",&rl)){
        counter++;
    }
//printf("%d",counter);
  int l;
 l = (int)sqrt(counter);
 int arr[l][l];
/* i = 0;
 while(i<counter){
        if(temp==48)
     arr[i/l][i%l] = (int)temp[i];
     i++;
 }*/
   FILE *fp2=fopen("D://array.txt","r");
      i=0;
    int j=0;
    while(EOF!=fscanf(fp2,"%d ",&rl)){
    arr[i][j]=rl;
    j++;
    if(j>=l){
    	j=0;
    	i++;
	}
    }

  int result =  2 ;

      while(result < l){
          result = result*2;
      }
//printf("%d %d",result,l);
  int a[result][result];
  for(int i=0;i<result -l;i++){
      for(int j=0;j<result;j++){
          a[i][j] = 0 ;
      }
  }
   for(int i=0;i<result;i++){
      for(int j=0;j<result - l;j++){
          a[i][j] = 0 ;
      }
  }
  int k = result - l;
  for(int i = 0;i < l;i++){
      for(int j = 0;j < l;j++){
          a[i+k][j+k] = arr[i][j];
      }
  }
  int r = result;
  int b[r][r];
  split(r,a,0,0,r,r,b);
  printr(r,b);
   return 0;}

/**
* This method is used to tell whether an array should be splited into subquadrants or not
* @author G.Mahidhar
* @param integer
* @date 18/08/2019
*/
int quad (int r ,int s[r][r], int x,int y,int width,int height){
  int counto = 0;
  int count1 = 0;
  for(int i = 0 ;i<width; i++){
      for(int j = 0;j <height;j++){
          if(s[j+y][i+x]==0){
              counto++;
          }
              else{
                  count1++;
              }

      }
  }
  if(counto==0 || count1==0){
      return 1;
  }
  else{
      return 0;
  }

  }


/**
* Depending on quad()method value this method is used to split the 2D - array into subquadrants
* @author G.Mahidhar
* @param maximal square array
* @date 18/08/2019
*/
  void split(int r ,int s[r][r], int x,int y,int width,int height,int b[r][r]){
if (quad(r,s,x,y,width,height)==1){
                  for (int i = 0; i < width; i++)   {
                 for (int j = 0; j < height; j++){
                 b[j+y][i+x] = akl;
                 } }
         int m=0;
         int u=width;
         while(u<r){
             m++;
             u=u*2;
         }
       printf("(%d,%d,%d)\n",akl,s[y][x],m) ;

     akl++;
     }
     else {
 split(r ,s , x, y, width/2, height/2,b); // Top left Quadrant
 split(r ,s , x + width/2, y, width/2, height/2,b); // Top right Q.
 split(r ,s, x, y + height/2, width/2, height/2,b); // Bottom left Q.
 split(r ,s, x + width/2, y + height/2, width/2, height/2,b); // Bottom right Q.
}
}

/**
* This method is used to print Maximal square array
* @author G.Mahidhar
* @param
* @date 18/08/2019
*/

  void printr(int r, int b[r][r]){
    for (int i = 0; i < r; i++)   {
                 for (int j = 0; j < r; j++){
                printf( "%d ",b[i][j]);
                 }
                 printf("\n");
         }
  }
