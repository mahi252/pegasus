var searchData=
[
  ['quad_9',['quad',['../_m_a_t_8c.html#af3db748f4163e6a91c2f6cbeb4693df6',1,'quad():&#160;MAT.c'],['../_m_a_t_8c.html#ab874963d1dadcbb42b89395b91aec809',1,'quad(int r, int s[r][r], int x, int y, int width, int height):&#160;MAT.c']]]
];
