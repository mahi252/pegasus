var searchData=
[
  ['split_5',['split',['../_m_a_t_8c.html#a77a30f2f7baa516e707d057a572a07ba',1,'split():&#160;MAT.c'],['../_m_a_t_8c.html#afc90157d7fdd7d816c79185996ceb862',1,'split(int r, int s[r][r], int x, int y, int width, int height, int b[r][r]):&#160;MAT.c']]]
];
