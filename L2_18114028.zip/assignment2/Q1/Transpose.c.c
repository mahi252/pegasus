
/**
* @file Transpose.c
* @brief this file is to encrpyt the given data
*
* @author G.Mahidhar
*
* @date 18/08/2019

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

 /**
* This method is used to encrypt the input_flie
* @author G.Mahidhar
* @param
* @date 18/08/2019
*/

 int main ( int argc,char *argv[]) {
 FILE *fp;
 char temp[1000];
 fp = fopen(argv[4], "r");
 int counter = 0,i ;
 if( fgets (temp, 1000, fp)!=EOF ) {
    // puts(temp);

 }
 fclose(fp);
 FILE *fp2 = fopen(argv[4], "r");
 int rl ;
 while(EOF!=fscanf(fp2,"%c",&rl)){
        counter++;
    }

 //for(int i = 0;i<13;i++){
   // printf("%c",temp[i]);
   // printf("%d",i);}
/*for(int i =0;i<1000;i++){
    if(temp[i]!= '/0'){
        counter++;
    }
}*/
//printf("%d",counter);
 int counter2;
  int n,a,b;
 n = atoi(argv[1]);
 a = atoi(argv[2]);
 b = atoi(argv[3]);
 counter2 = counter/n;
 counter2 = (counter2+1) *n;
 char arr[counter2];

 /*if( fgets (temp, 1000, fp)!=EOF ) {
     puts(temp);
     i++;
 }*/
 //fclose(fp);
 i=0;
 while(i<counter+1){
     arr[i]=temp[i];
     i++;
 }
/*for(int i = 0;i<counter2;i++){
    printf("%c",arr[i]);
}*/

 char out[counter2];
 int p,q,k;

 for(i = counter; i < counter2; i++ ){
arr[i] = '\0';
 }

 k=1;
 while(k<=counter2){
     if(k%n != n){
 i = k%n - 1;}
 else{
     i = n - 1;
 }
     p = (k/n)*n + (a*i + b)%n ;
 out[k-1] = arr[p];
 k++;
 }

 for(i=0;i<counter2;i++)
 printf("%c",out[i]);

 FILE *output_file = fopen("D:\\output_file.txt", "w");
    if (output_file == NULL)
    {
        printf("Error opening file!\n");
        exit(1);
    }

   int f=0;

    while(f<counter2){
        fprintf(output_file,"%c",out[f]);
        f++;
    }
 fclose(output_file);
 return 0;
 }









