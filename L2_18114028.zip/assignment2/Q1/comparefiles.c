
/**
* @file comparefiles.c
* @brief this file is to compare decrypted file with the input_file
*
* @author G.Mahidhar
*
* @date 18/08/2019
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char c1,c2,arr1[1000],arr2[1000],check=0;
int p=0,q=0;
FILE *fp1;
FILE *fp2;

/**
* This method is used to compare decrypted message and input message
* @author G.Mahidhar
* @param
* @date 18/08/2019
*/
int main(){
   /*Opening the two .txt files*/
  fp1=fopen("D://input_file.txt","r");
  fp2=fopen("D://decryptedOutput_file.txt","r");

if(fp1==NULL || fp2==NULL){
 printf("Please check your files...");
       return;
}
 while(((c1=fgetc(fp1))!=EOF)&&c1!='\0'){

    arr1[p]=c1;
    p++;
 }
  while(((c2=fgetc(fp2))!=EOF)&&c2!='\0'){
    arr2[q]=c2;
       q++;
  }
  /*Checking whether they are the same*/
 if(p!=q){
    check=1;
     printf("\nThe files are not same");
   }
 else{
      q=0;
      while(q<p){
           if(arr1[q]!=arr2[q]){
            check=1;
        printf("\nThe files are not same");
      break;
           }
        q++;
       }
  }
 if(check==0)
      printf("\nBoth the files are same\n");
   fclose(fp1);
   fclose(fp2);
return 0;

}




















