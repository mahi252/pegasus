
#include <bits/stdc++.h>
#include <iostream>
using std::cerr;
using std::endl;
#include <fstream>
using std::ofstream;
#include <cstdlib>
using namespace std;


class  Edge
{
    public:

    int src , dest, weight;
};


class  Graph
{
    public:
    int V , E;


    Edge*  edge;
};


Graph* createGraph(int V, int E)
{
    Graph* graph = new Graph;

    graph->V = V;
    graph->E = E;
    graph->edge = new  Edge[E];

    return graph;
}


class  subset
{
    public:
    int   parent;
    int  rank;
};


int find(subset  subsets[] ,  int i)
{

    if  (subsets[i].parent != i)

        subsets[i].parent = find(subsets, subsets[i].parent);

    return subsets[i].parent;
}

void Union(subset subsets[] , int x , int y)
{
    int xroot = find(subsets , x);
    int yroot = find(subsets , y);


    if (subsets[xroot].rank < subsets[yroot].rank)
        subsets[xroot].parent = yroot;
    else if (subsets[xroot].rank > subsets[yroot].rank)
        subsets[yroot].parent = xroot;


    else
    {
        subsets[yroot].parent = xroot;
        subsets[xroot].rank++;
    }
}


int myComp (const void* a, const void* b)
{
    Edge* a1 = (Edge*)a;
    Edge* b1  = (Edge*)b;
    return a1->weight > b1->weight;
}


void KruskalMST(Graph*  graph)
{
    int V = graph->V;
    Edge  result[V];
    int e = 0;
    int i = 0;


    qsort(graph->edge, graph->E, sizeof(graph->edge[0]), myComp);


    subset *subsets =   new subset[( V * sizeof(subset) )];


    for (int v = 0 ; v < V ; ++v)
    {
        subsets[v].parent  = v;
        subsets[v].rank = 0;
    }


    while (e < V - 1  && i < graph->E)
    {

        Edge next_edge  = graph->edge[i++];

        int x = find(subsets, next_edge.src);

        int y = find(subsets, next_edge.dest);


        if (x !=  y)

        {
            result[e++] = next_edge;
            Union(subsets, x, y);
        }

    }


    ofstream filec;
    filec.open("D:\Demo.csv");
   if( !filec ) {
      cerr << "Error: file could not be opened" << endl;
      exit(1);
   }
    printf("Following are the edges in the constructed MST\n");
     i=e;
    while(i--){
        cout<<(char)(result[i].src+65)<<" "<<(char)(result[i].dest+65)<<" "<<result[i].weight<<endl;
        filec<<(char)(result[i].src+65)<<"--"<<(char)(result[i].dest+65)<<"[label=\""<<result[i].weight<<"\"]"<<endl;
    }
    filec.close();
    return;
}


int main()
{

    int V =  100; // Number of vertices in graph
    int E = 100,s=0,count=0,i;// Number of edges in graph

    Graph*  graph = createGraph( V, E );

    FILE *fp=fopen("D:\p2_input.csv","r");
    char ch;
    int  c1[100] , c2[100];
    int a[100]  ,store[100];

    while(EOF!=fscanf(fp,"%c",&ch)){ s--; //cout<<ch;
        if(ch=='\n') s=1;
      if(ch==',') count++;
      if(ch!=','&&ch!='\n'&&(int)ch>45){
      if(count%2==0){
    if(s>=0||count==0) {c1[count/2]=(int)ch-65;  }
        else{ if((int)ch!=13) a[count/2-1]=(int)ch; if(a[count/2-1]>13) a[count/2-1]-=48;  }
      }
      else{
         c2[(count-1)/2]=(int)ch-65;
      }
  }
    }

    for(i=0;i<count/2;i++){
    graph->edge[i].src = c1[i];
    graph->edge[i].dest = c2[i];
    graph->edge[i].weight = a[i];
    }

    KruskalMST(graph);

    return 0;
}
